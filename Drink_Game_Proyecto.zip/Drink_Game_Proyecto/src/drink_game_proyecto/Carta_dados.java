/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package drink_game_proyecto;

import java.util.Random;

/**
 *
 * @author Principal
 */
public class Carta_dados extends Datos{
    public Carta_dados(String Nombre, String Descripcion){
        super(Nombre, Descripcion);
    }
    
    public String NuevoJuego(){
        String[] juegos = {"1.Personalidades", "2. Sillas musicales", "3. Bebe y luego intenta voltear el vaso con el dedo meñique", "4. Memoria", "5. Yo nunca nunca", "6. Mimica", "7. cerveza pong", "8. memoriza el animal", "9. 5 MINUTOS EN EL CIELO", "10 Art attack"};
        Random random = new Random();
        int indice = random.nextInt(juegos.length);
        return juegos[indice];
    }
    
}
