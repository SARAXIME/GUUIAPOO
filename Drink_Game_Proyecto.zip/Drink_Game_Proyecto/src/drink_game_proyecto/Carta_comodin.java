/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package drink_game_proyecto;

import java.util.Random;

/**
 *
 * @author Principal
 */
public class Carta_comodin extends Datos implements cumplir_reto, tomar_shot {
    public Carta_comodin(String Nombre, String Descripcion){
        super(Nombre, Descripcion);
    }
    public String NuevoComodin(){
        String[] comodin = {"Comodin Saltar", "Comodin Bailar", "Comodin Cantar", "Comodin Adivinanzas", "Comodin Mimica", "Comodin Ejercicio"};
        Random random = new Random();
        int indice = random.nextInt(comodin.length);
        return comodin[indice];
    }
    
    @Override
    public void cumplir_reto(){
        
    }
    public void tomar_shot(){
        
    }
    
}
