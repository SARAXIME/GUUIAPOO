/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package drink_game_proyecto;

import java.util.Random;

/**
 *
 * @author Principal
 */
public class Carta_regla extends Datos{
    public Carta_regla(String Nombre, String Descripcion){
        super(Nombre, Descripcion);
    }
    public String NuevaRegla(){
        String[] reglas = {"1.Por cada groseria deberás tomar 2 shots",
"2.       Por cada shot que tome tu amigo de la izquierda deberás tomar 2 shots",
"3.       Si te ries en las próximas 3 rondas deberás tomar 3 shots",
"4.       Por cada vez que mienta uno del grupo deberás tomar 2 shots",
"5.       Por cada vez que alguien diga el nombre de una persona del grupo deberás tomar 2 shots",
"6.       Cada vez que alguien nombre a un animal deberás tomar 4 shots",
"7.       Habla sobre ti mismo en tercera persona durante el próximo turno por cada vez que se te olvide tomaras 4 shots",
"8.       Solo vas a poder decir los nombres de tus ex en vez de los integrantes del grupo por las siguientes 4 rondas.",
"9.       Cada vez que alguien se pare deberás tomar 2 shots",
"10.   Por cada vez que alguien te nombre deberás tomar 1 shot."};
        Random random = new Random();
        int indice = random.nextInt(reglas.length);
        return reglas[indice];
    }
    
}
