/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package drink_game_proyecto;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author Principal
 */
public class Drink_Game_Proyecto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Empezar_1().setVisible(true);
        Tiempo tiempo = new Tiempo();

        // Esperar 5 segundos antes de iniciar el bucle
        try {
            Thread.sleep(5000); // 5000 milisegundos = 5 segundos
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Bucle para seleccionar al azar una carta
        Random random = new Random();
        while (true) {
            // Lógica para elegir una carta al azar
            int cartaSeleccionada = random.nextInt(4); // Reemplaza 3 con el número total de cartas

            // Lógica para mostrar la carta en el JFrame
            switch (cartaSeleccionada) {
                case 0:
                    new Dados().setVisible(true);
                    tiempo.ContarTiempo();
                    break;
                case 1:
                    new Comodin().setVisible(true);
                    tiempo.ContarTiempo();
                    break;
                case 2:
                    new Reto().setVisible(true);
                    tiempo.ContarTiempo();
                    break;
                case 3:
                    new Regla().setVisible(true);
                    tiempo.ContarTiempo();
                    break;
            }

            try {
                Thread.sleep(60000); // 60000 milisegundos = 60 segundos = 1 minuto
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
    }
    
}
