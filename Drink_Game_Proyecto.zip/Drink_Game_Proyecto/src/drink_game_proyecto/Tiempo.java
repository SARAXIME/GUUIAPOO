/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package drink_game_proyecto;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Tiempo {

    public void ContarTiempo() {
        Thread countdownThread = new Thread(() -> {
            for (int i = 60; i >= 0; i--) {
                final int currentCount = i;
                SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null, currentCount));

                try {
                    Thread.sleep(1000); 
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        countdownThread.start();
    }

    public static void main(String[] args) {
        Tiempo tiempo = new Tiempo();
        tiempo.ContarTiempo();
    }
}