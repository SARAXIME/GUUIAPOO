/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package drink_game_proyecto;

/**
 *
 * @author Principal
 */
public interface tomar_shot {
    public void tomar_shot();
    
}
