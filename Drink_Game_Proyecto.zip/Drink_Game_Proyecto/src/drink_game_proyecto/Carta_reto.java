/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package drink_game_proyecto;

import java.util.Random;

/**
 *
 * @author Principal
 */
public class Carta_reto extends Datos implements cumplir_reto, tomar_shot {
    public Carta_reto(String Nombre, String Descripcion) {
        super(Nombre, Descripcion);
    }
    
    public String obtenerRetoAlAzar() {
        String[] retos = {
    "1. Toma un shot de una mezcla de bebidas elegida por el grupo.",
    "2. Llama a tu ex y cantan \nuna canción romántica",
    "3. Comparte tu secreto más \noscuro o vergonzoso.",
    "4. Comparte un secreto \nvergonzoso sobre \nalguien más en el grupo.",
    "5. Realiza una búsqueda \nrápida en internet y lee en voz \nalta la última búsqueda que hayas hecho.",
    "6. Toma un shot por cada\n año que hayas estado \nen una relación.",
    "7. Besa a la persona\n a tu izquierda durante al \nmenos 30 segundos.",
    "8. Realiza una llamada a\n un servicio de entrega de comida y\n coquetea con la persona que atienda.",
    "9. Comparte una fantasía\n que hayas tenido \nrecientemente",
    "10. Crea una historia \nerótica corta y léela \nen voz alta,",
    "11. Haz una llamada de broma \na un número aleatorio y coquetea\n con la persona que conteste",
    "12. Toma un shot por cada \nvez que hayas besado a \nalguien en el último año",
    "13. Envía un mensaje de\n texto a tu jefe o profesor\n diciendo que no puedes con las ganas de verlo",
    "14. Dibuja un tatuaje \ntemporal en tu cuerpo con un \nmarcador permanente",
    "15. Envía una foto VERGONZOSA\n a la tercera persona \nen tu lista de contactos",
    "16. Realiza una llamada\n a un amigo y dile que te \nenamoraste de él/ella en secreto",
    "17. Toma un shot por cada \nmes que hayas estado soltero/a en \nlos últimos dos años",
    "18. Besa a la persona \na tu derecha en el \nlugar que elijan",
    "19. Envía un mensaje de \ntexto a tu ex diciendo que todavía\n tienes sentimientos por él/ella"
};

        Random random = new Random();
        int indice = random.nextInt(retos.length);
        return retos[indice];
    }
    public String obtenerShotAlAzar() {
        String[] shots = {"1 Shot", "2 Shots", "3 Shots"};
        Random random = new Random();
        int indice = random.nextInt(shots.length);
        return shots[indice];
    }
    
    @Override
    public void cumplir_reto(){
        
    }
    public void tomar_shot(){
        
    }
    
}
